var group__kvadb__database =
[
    [ "kvaDbAddFile", "group__kvadb__database.html#ga5b519b0fee0fb480488a5a5c628c863a", null ],
    [ "kvaDbClose", "group__kvadb__database.html#ga08c85db8a33c4dcdb9d1114b72ab7c30", null ],
    [ "kvaDbCreate", "group__kvadb__database.html#ga0da72bb21d2664d6443f7b3349ec9df5", null ],
    [ "kvaDbGetDatabaseName", "group__kvadb__database.html#gaeacbe7c03340e8134181727b7f16958f", null ],
    [ "kvaDbGetErrorText", "group__kvadb__database.html#gaef428f2f4f23c81ada89b8317683c276", null ],
    [ "kvaDbGetFlags", "group__kvadb__database.html#ga04b35b1f5416157cb633cf7c44df396e", null ],
    [ "kvaDbGetLastParseError", "group__kvadb__database.html#ga2b96a31d3ff595c861656bfd2ac43d55", null ],
    [ "kvaDbGetProtocol", "group__kvadb__database.html#gaa0f4c9ff207860723464907c2cc388c4", null ],
    [ "kvaDbGetProtocolProperties", "group__kvadb__database.html#gaf59a935265ee9b7457b6fdbe493c8d49", null ],
    [ "kvaDbGetVersion", "group__kvadb__database.html#gabe66bb4a8311ee7503e117ec392378b3", null ],
    [ "kvaDbOpen", "group__kvadb__database.html#gacbcd92e8da46f1b756c72d25ab92d240", null ],
    [ "kvaDbReadFile", "group__kvadb__database.html#gaadd6d76a4a37fce5dacddc973951e8c8", null ],
    [ "kvaDbSetDummyFileName", "group__kvadb__database.html#ga927869d77b7bde7a2b0384dc6ec8c759", null ],
    [ "kvaDbSetFlags", "group__kvadb__database.html#ga0749d01aa354efde03f7141a59dc9de4", null ],
    [ "kvaDbSetProtocol", "group__kvadb__database.html#gaefa8ebb68ad9d0f5fcb397b675f29f3a", null ],
    [ "kvaDbWriteFile", "group__kvadb__database.html#gabf1db33bc6778e2f77ab1b66e8f743e9", null ]
];
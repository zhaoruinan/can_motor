var group__lin__general =
[
    [ "linGetChannelData", "group__lin__general.html#gac5c5dadc7ca9d70c627058a9b2b06231", null ],
    [ "linGetFirmwareVersion", "group__lin__general.html#gafa260028be850e70a99c1b0706679583", null ],
    [ "linGetVersion", "group__lin__general.html#ga6a182f2608e54e273f80f27770afa9dc", null ],
    [ "linInitializeLibrary", "group__lin__general.html#gaf47a1f1078f6b3919e2b2d9dfd559d8b", null ],
    [ "linReadTimer", "group__lin__general.html#ga8af35ecbb1aca56baed27990f3d43d4b", null ],
    [ "linUnloadLibrary", "group__lin__general.html#ga3b6bd0017ef68891ac1843a5921f81da", null ]
];
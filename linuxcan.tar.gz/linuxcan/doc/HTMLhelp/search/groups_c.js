var searchData=
[
  ['real_20time_20clock',['Real Time Clock',['../group__kvm__rtc.html',1,'']]]
];

var searchData=
[
  ['maxmessagedlc',['maxMessageDlc',['../struct_kva_db_protocol_properties.html#acea8c05d06bb3303dd71b41bec875533',1,'KvaDbProtocolProperties']]],
  ['maxsignallength',['maxSignalLength',['../struct_kva_db_protocol_properties.html#a4f81fb4d85cd39f1658a64e087321245',1,'KvaDbProtocolProperties']]],
  ['msg',['msg',['../structkvm_log_event_ex.html#ae3dbb7c786bd2bdd9d47bbaccbb17539',1,'kvmLogEventEx']]]
];

var searchData=
[
  ['open_20channel',['Open Channel',['../page_user_guide_chips_channels.html',1,'page_canlib']]]
];

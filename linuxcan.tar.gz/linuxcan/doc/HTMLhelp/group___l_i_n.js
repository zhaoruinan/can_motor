var group___l_i_n =
[
    [ "linBusOff", "group___l_i_n.html#ga051ffc0c24d6322825cbc8ff21e50744", null ],
    [ "linBusOn", "group___l_i_n.html#ga79ab73655c1749ad9fe2b784885e2dd9", null ],
    [ "linClearMessage", "group___l_i_n.html#ga905647480dd89a7225e4b8ae0d82cb92", null ],
    [ "linClose", "group___l_i_n.html#ga5d8cb59baccdefc9e772ad34c01c596f", null ],
    [ "linGetCanHandle", "group___l_i_n.html#gadf904a2ba0101ac6dc622b6035cf0f5f", null ],
    [ "linGetTransceiverData", "group___l_i_n.html#ga95408cd6c8639514b4be8e188bd7b38a", null ],
    [ "linOpenChannel", "group___l_i_n.html#ga040336f8176a10cb9578b47c42baef6b", null ],
    [ "linReadMessage", "group___l_i_n.html#gaca2d874c870f16c11a4e8e158817d8bf", null ],
    [ "linReadMessageWait", "group___l_i_n.html#gaa2f729a931bf644ce62b373ab7414250", null ],
    [ "linRequestMessage", "group___l_i_n.html#ga068419b8b624d8918720a8907c4f9274", null ],
    [ "linSetBitrate", "group___l_i_n.html#ga77e1463234ee6c67a71a2ab57f578b7f", null ],
    [ "linSetupIllegalMessage", "group___l_i_n.html#ga1c89e03300af644cee54861f92ae567e", null ],
    [ "linSetupLIN", "group___l_i_n.html#ga911287175a2ca5574a50d17b698b6d9d", null ],
    [ "linUpdateMessage", "group___l_i_n.html#ga5bf84820248e95fde2718fa46304a5a5", null ],
    [ "linWriteMessage", "group___l_i_n.html#gac012f34a621bc885bd582398c3d5d175", null ],
    [ "linWriteSync", "group___l_i_n.html#ga1bd437b46f5923f05905c43cd4a1617a", null ],
    [ "linWriteWakeup", "group___l_i_n.html#ga4ba0a5256a785f3cc67a5e661837223e", null ]
];
var group__kvdiag__setup =
[
    [ "kvDiagAlloc", "group__kvdiag__setup.html#ga28b98f7100fa0bb9cb23e5848c10940d", null ],
    [ "kvDiagAttach", "group__kvdiag__setup.html#gabea2d51b6e961ba21e9c62ea24d6621f", null ],
    [ "kvDiagDealloc", "group__kvdiag__setup.html#ga2a6950ff605deae5dfb7cba70e883e00", null ],
    [ "kvDiagDetach", "group__kvdiag__setup.html#ga8f1f2a2caca8b798987fa1f24147bccf", null ]
];